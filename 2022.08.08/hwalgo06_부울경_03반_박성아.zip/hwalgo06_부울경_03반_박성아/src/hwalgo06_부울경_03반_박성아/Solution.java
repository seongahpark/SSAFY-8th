package hwalgo06_�ο��_03��_�ڼ���;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class Solution {

	static int T;
	static int N, M, res;
	static ArrayList<Integer> arr;
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		T = Integer.parseInt(br.readLine());
		
		for(int t=1; t<=T; t++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			
			arr = new ArrayList<>();
			st = new StringTokenizer(br.readLine());
			for(int i=0; i<N; i++) {
				arr.add(Integer.parseInt(st.nextToken()));
			}
			
			Collections.sort(arr, Collections.reverseOrder());
			
			res = -1;
			
			dfs(0, 0, 0);
			
			System.out.println("#" + t + " " + res);
		}
		
		br.close();
	}
	
	public static void dfs(int cnt, int idx, int sum) {
		if(sum > M) return;
		if(cnt == 2) {
			res = Math.max(res, sum);
			return;
		}
		if(idx == N) return;
		
		dfs(cnt+1, idx+1, sum+arr.get(idx));
		dfs(cnt, idx+1, sum);
	}

}
