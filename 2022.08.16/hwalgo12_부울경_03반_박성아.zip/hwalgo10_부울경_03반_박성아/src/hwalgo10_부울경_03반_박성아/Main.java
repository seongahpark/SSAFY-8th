package hwalgo10_�ο��_03��_�ڼ���;

import java.util.*;
import java.io.*;

public class Main {

	static int N;
	static int [][] arr;
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine());
		arr = new int[N][2];
		
		int count = 1;
		
		for(int i=0; i<N; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			arr[i][0] = Integer.parseInt(st.nextToken());
			arr[i][1] = Integer.parseInt(st.nextToken());
		}
		
		Arrays.sort(arr, (n1, n2) -> n1[1] - n2[1]);
		
		int max = arr[0][1];
		
		for(int i=0; i<N; i++) {
			if(arr[i][0] <= max) {
				if(arr[i][1] < max)
					max = arr[i][1];
				continue;
			}
			else {
				max = arr[i][1];
				count++;
			}
		}
		
		System.out.println(count);
	}

}
