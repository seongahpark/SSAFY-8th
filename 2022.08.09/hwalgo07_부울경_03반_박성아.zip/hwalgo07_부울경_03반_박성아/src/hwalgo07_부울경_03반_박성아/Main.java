package hwalgo07_�ο��_03��_�ڼ���;

import java.io.*;
import java.util.*;

public class Main {
	
	static int res, N;
	static boolean [][] arr = new boolean[100][100];

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine());
		
		while(N-- > 0) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int x = Integer.parseInt(st.nextToken());
			int y = Integer.parseInt(st.nextToken());
			
			for(int i=x; i<x+10; i++) {
				for(int j=y; j<y+10; j++) {
					if(!arr[i][j]) {
						res++;
						arr[i][j] = true;
					}
				}
			}
		}
		System.out.println(res);
		br.close();
	}

}
