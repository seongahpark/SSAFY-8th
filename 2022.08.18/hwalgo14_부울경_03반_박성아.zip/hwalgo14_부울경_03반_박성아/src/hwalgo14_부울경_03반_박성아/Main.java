package hwalgo14_부울경_03반_박성아;

import java.util.*;

public class Main {
	static int arr[][];
	static int visit[]; 
	static Queue<Integer> q = new LinkedList<>();
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);	
		
		int n = sc.nextInt(); 
		int m = sc.nextInt(); 
		int v = sc.nextInt();
		
		arr = new int[n+1][n+1];
		visit = new int[n+1];
		
		for(int i=0; i<m; i++) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			arr[a][b] =1;
			arr[b][a]= 1;
		}
		
		dfs(v);
		Arrays.fill(visit, 0); 
		System.out.println();
		bfs(v);
	}
	
	static void dfs(int x) { 
		if(visit[x] == 1) return; 
		
		visit[x] = 1;
		System.out.print(x+" ");
		for(int i =1; i<arr.length; i++) {
			if(arr[x][i] == 1) dfs(i);
		}
	}
	
	static void bfs(int x) { 
		q.add(x); 
		visit[x] = 1;
		
		while(!q.isEmpty()) { 
			x = q.poll(); 
			System.out.print(x+" ");
			for(int i =1; i<arr.length; i++) { 
				if(visit[i]!= 1 && arr[x][i] == 1 ) {
					q.add(i);
					visit[i] =1; 
				}
			}
		}
	}
	
}