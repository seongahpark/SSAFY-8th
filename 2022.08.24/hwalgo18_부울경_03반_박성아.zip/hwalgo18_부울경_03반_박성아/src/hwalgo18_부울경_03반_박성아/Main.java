package hwalgo18_부울경_03반_박성아;

import java.io.*;
import java.util.*;

public class Main {

	static int n, cnt;
	static char [][] arr;
	static boolean [][] visit;
	
	static int [] dx = { 0, 0, 1, -1};
	static int [] dy = { 1, -1, 0, 0};
	
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		
		arr = new char[n][n];
		visit = new boolean[n][n];
		
		for(int i=0; i<n; i++) {
			arr[i] = br.readLine().toCharArray();
		}
		
		solve();
		
		for(int i=0; i<n; i++) {
			for(int j=0; j<n; j++) {
				if(arr[i][j] == 'G') arr[i][j] = 'R';
			}
		}
		
		for(int i=0; i<n; i++) {
			Arrays.fill(visit[i], false);
		}
		
		solve();
	}
	
	static void solve() {
		cnt = 0;
		for(int i=0; i<n; i++) {
			for(int j=0; j<n; j++) {
				if(!visit[i][j]) {
					dfs(i, j);
					cnt++;
				}
			}
		}
		System.out.print(cnt + " ");
	}
	
	static void dfs(int x, int y) {
		visit[x][y] = true;
		for(int i=0; i<4; i++) {
			int nx = x + dx[i];
			int ny = y + dy[i];
			
			if(nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
			if(visit[nx][ny] || arr[x][y] != arr[nx][ny]) continue;
			dfs(nx, ny);
		}
	}
}
