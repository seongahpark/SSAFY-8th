package hwalgo08_�ο��_03��_�ڼ���;

// BOJ 1010 �ٸ� ����

import java.util.*;
import java.io.*;
public class Main {

	static int T;
	static int [][] arr = new int[30][30];
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		T = Integer.parseInt(br.readLine());
		
		while(T-- > 0) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			int m = Integer.parseInt(st.nextToken());
			System.out.println(comb(m, n));
		}
	}
	
	static int comb(int n, int r) {
		if(n == r || r == 0) return 1;
		if(arr[n][r] != 0) return arr[n][r];
		return arr[n][r] = comb(n-1, r-1) + comb(n-1, r);
	}

}
