package hwalgo15_부울경_03반_박성아;

import java.util.*;
import java.io.*;

public class Main {
	
    static class Archer {
        int row;            
        int column;         
        int tR;      
        int tC;   
 
        public Archer(int row, int column) {
            this.row = row;
            this.column = column;
        }
    }
    
    static int N, M, D, cnt, res;
    static int[][] arr;
 
    static List<Archer> archers = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        N = Integer.parseInt(st.nextToken());
        M = Integer.parseInt(st.nextToken());
        D = Integer.parseInt(st.nextToken());
 
        arr = new int[N][M];
        for (int i = 0; i < N; i++) {
        	st = new StringTokenizer(br.readLine());
            for (int j = 0; j < M; j++) {
                arr[i][j] = Integer.parseInt(st.nextToken());
            }
        }

        search(0);

        System.out.println(res);
    }
 
    static void search(int index) {
    	// 기저 조건
        if (archers.size() == 3) {

            int[][] testArr = new int[N][M];
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < M; j++) {
                    testArr[i][j] = arr[i][j];
                }
            }

            int enemy = 99;

            while (enemy > 0) {
                for (Archer archer : archers) {
                    archer.tR = -1;
                    archer.tC = -1;
                    
                    int min = Integer.MAX_VALUE;

                    for (int j = 0; j < M; j++) {
                        for (int i = N-1; i >= 0; i--) {
                            if (testArr[i][j] == 1) {
                                int tmp = Math.abs(i-archer.row) + Math.abs(j- archer.column);

                                if (tmp > D) break;
                                if (min > tmp) {
                                    min = tmp;
                                    archer.tR = i;
                                    archer.tC = j;
                                }
                            }
                        }
                    }
                }
 
                for (Archer archer : archers) {
                    if (archer.tR != -1) {
                        if (testArr[archer.tR][archer.tC] == 1) {
                            testArr[archer.tR][archer.tC] = 0;
                            cnt++;
                        }
                    }
                }

                enemy = 0;

                for (int j = 0; j < M; j++) {
                    for (int i = N - 1; i >= 0; i--) {
                        if (testArr[i][j] == 1) {
                            int moveR = i + 1;
                            if (moveR >= N) {
                                testArr[i][j] = 0;
                            } else {
                                testArr[i][j] = 0;
                                testArr[moveR][j] = 1;
 
                                enemy++;
                            }
                        }
                    }
                }
            }
            res = Math.max(res, cnt);
            cnt = 0;

            return;
        }
 
        for (int i = index; i < M; i++) {
            archers.add(new Archer(N, i));
            search(i + 1);
            archers.remove(archers.size()-1);
        }
    }
}