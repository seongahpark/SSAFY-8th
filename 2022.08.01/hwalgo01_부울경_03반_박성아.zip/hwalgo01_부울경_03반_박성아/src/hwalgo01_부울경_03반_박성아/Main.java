package hwalgo01_부울경_03반_박성아;
import java.util.*;
import java.io.*;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// 남학생 -> 배수에 해당하는 스위치 변경 
		// 여학생 -> 받은 수의 위치에 섬, 좌우 대칭, 가장 많은 스위치 포함 (홀수개)
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		int [] arr = new int[n+1];
		String[] tmp = br.readLine().split(" ");
		for(int i =1 ;i<=n; i++) arr[i] = Integer.parseInt(tmp[i-1]);
		
		int stu = Integer.parseInt(br.readLine());
		for(int i=0; i<stu; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int gender = Integer.parseInt(st.nextToken());
			int button = Integer.parseInt(st.nextToken());
			
			if(gender == 1) {
				for(int j = button; j<=n; j++) {
					if(j % button == 0) {
						if(arr[j] == 0) arr[j] = 1;
						else arr[j] = 0;
					}
				}
			}else if(gender == 2) {
				int chk = Math.min(button - 1, n - button);
				int start = button - chk;
				
				// 대칭인 곳 인덱스 찾음 
				for(int j=1; j<=chk; j++) {
					if(arr[button-j] != arr[button+j]) {
						start = button - j + 1;
						chk = j - 1;
						break;
					}
				}
				
				// 배열 변경
				for(int j=start; j<=button+chk; j++) {
					if(arr[j] == 0) arr[j] = 1;
					else arr[j] = 0;
				}
			}
		}

		StringBuilder sb = new StringBuilder();
		for(int i=1; i<=n; i++) {
			sb.append(arr[i] + " ");
			if(i % 20 == 0 ) sb.append(System.getProperty("line.separator"));
		}
		
		System.out.print(sb);

		br.close();
	}

}
